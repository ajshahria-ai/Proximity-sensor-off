package com.example.proximitycallbypass

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sw=findViewById<Switch>(R.id.enableSwitch)
        val status=findViewById<TextView>(R.id.statusText)

        requestNeededPermissions()

        val p=getSharedPreferences("settings",MODE_PRIVATE)
        sw.isChecked=p.getBoolean("enabled",false)
        status.text=if(sw.isChecked)"চালু" else "বন্ধ"
        sw.setOnCheckedChangeListener { _, enabled ->
            p.edit().putBoolean("enabled",enabled).apply()
            status.text=if(enabled)"চালু" else "বন্ধ"
            val i=Intent(this,CallMonitorService::class.java)
            if(enabled) ContextCompat.startForegroundService(this,i) else stopService(i)
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        // POST_NOTIFICATIONS is required at runtime on API 33+ (Android 13+) for the
        // foreground-service notification to show; on API < 33 this permission does not
        // exist and is silently ignored by the system.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 10)
        }
    }
}
