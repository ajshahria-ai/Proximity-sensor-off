package com.example.proximitycallbypass

import android.app.*
import android.content.*
import android.os.*
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

// IMPORTANT / HONESTY NOTE:
// This service does NOT disable, override, or gain any control over the physical
// proximity sensor. Android exposes no public API that lets a third-party app turn
// the proximity sensor off or block it from reporting "near" events.
// All this does is hold a wake lock while a call is active, hoping to keep the
// screen from dimming/blanking. During an actual phone call, the stock ColorOS
// Phone app independently manages its own proximity-based screen-off behavior at
// the system level, and a third-party app has no supported way to override that.
// In practice, on many OEM skins (ColorOS included) this bypass will have little
// or no effect during real calls. It's most useful for keeping the screen on
// during things like speakerphone-only VoIP flows where nothing else is holding
// a competing proximity wake lock.
class CallMonitorService: Service() {
    private var receiver: BroadcastReceiver?=null
    private var lock: PowerManager.WakeLock?=null

    override fun onCreate(){
        super.onCreate()
        val ch=NotificationChannel("call_bypass","Call Bypass",NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n=Notification.Builder(this,"call_bypass")
            .setContentTitle("Proximity Call Bypass")
            .setContentText("কলের সময় screen awake রাখার চেষ্টা চলছে")
            .setSmallIcon(android.R.drawable.ic_menu_call).setOngoing(true).build()
        startForeground(10,n)

        receiver=object:BroadcastReceiver(){
            override fun onReceive(c:Context?,i:Intent?){
                if(i?.action!=TelephonyManager.ACTION_PHONE_STATE_CHANGED)return
                when(i.getStringExtra(TelephonyManager.EXTRA_STATE)){
                    TelephonyManager.EXTRA_STATE_RINGING,
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> acquire()
                    TelephonyManager.EXTRA_STATE_IDLE -> release()
                }
            }
        }
        // ContextCompat.registerReceiver works correctly on API 26 (this app's minSdk)
        // through API 35+, unlike calling Context.registerReceiver's 3-arg overload
        // directly, which only exists starting on API 33 and would crash on this
        // device's Android 12 (API 31).
        ContextCompat.registerReceiver(
            this,
            receiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }
    private fun acquire(){
        if(lock?.isHeld==true)return
        val pm=getSystemService(POWER_SERVICE) as PowerManager
        lock=pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "ProximityCallBypass:Wake"
        )
        lock?.acquire(4*60*60*1000L)
    }
    private fun release(){if(lock?.isHeld==true)lock?.release()}
    override fun onDestroy(){receiver?.let{unregisterReceiver(it)};release();super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
